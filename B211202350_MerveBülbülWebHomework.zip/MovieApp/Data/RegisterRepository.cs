using System.Collections.Generic;
using System.Linq;
using MovieApp.Models;


namespace MovieApp.Data
{

    public static class RegisterRepository
    {
    
        private static List<User> _Users=new List<User>(); 

        public static List<User> Users{
            get{
                return _Users;
            }
        }  
        public static void AddUser(User std)
        {
            _Users.Add(std);
        }

    

        
    }

}
