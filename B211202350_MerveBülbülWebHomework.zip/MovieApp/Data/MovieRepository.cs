using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using MovieApp.Models;



namespace MovieApp.Data
{

    public static class MovieRepository
    {

        private static List<Movie> _movies = new List<Movie>();

        static MovieRepository()
        {
            _movies = new List<Movie>()
          {

              new Movie()
               {
                Id=1,
                Name="Interstellar",
                 ShortDescription="Interstellar",
                  Description="A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
                   CategoryId=1,
                     ImageUrl="Interstellar.jpg"
                },
              
              new Movie()
               {
               Id=2,
               Name="Forrest Gump",
                ShortDescription="Forrest Gump",
                  Description="The presidencies of Kennedy and Johnson, the Vietnam War, the Watergate scandal and other historical events unfold from the perspective of an Alabama man with an IQ of 75, whose only desire is to be reunited with his childhood sweetheart.",
                   CategoryId=2,
                    ImageUrl="Forrest_Gump.jpg"
               },
              
              new Movie()
              {
              Id=3,
              Name="Inception",
                ShortDescription="Inception",
                 Description="A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O., but his tragic past may doom the project and his team to disaster.",
                  CategoryId=3,
                   ImageUrl="Inception.jpg"
              },
              
              new Movie()
               {
                Id=4,
                Name="SocialNetwork",
                 ShortDescription="SocialNetwork",
                  Description="As Harvard student Mark Zuckerberg creates the social networking site that would become known as Facebook, he is sued by the twins who claimed he stole their idea, and by the co-founder who was later squeezed out of the business.",
                   CategoryId=4,
                    ImageUrl="SocialNetwork.jpg"
              }


          };
        }
        public static List<Movie> Movies
        {
            get
            {
                return _movies;
            }
        }

        public static void AddMovie(Movie entity)
        {
            _movies.Add(entity);
        }


        public static Movie GetById(int id)
        {

            return _movies.FirstOrDefault(i => i.Id == id);
        }



    }

}