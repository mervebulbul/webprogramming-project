MovieApp is mvc core application that contains movie information according to categories.

Goals
This site aims to show the description of the movies by listing the movies in the category selected by the user.
In this way, the user can easily decide on the movie he wants to watch.
The user can access location information.
You can register on the site.
And can view the registrants.

Structure
/home Displays the homepage of the site.
/home/Index/1 lists movies belonging to the sci-fi category.
/home/Index/2 lists movies belonging to the drama category.
/home/Index/3 lists movies belonging to the adventure category.
/home/Index/4 lists movies that belong to the biography category.
/Home/Details/1 Displays the content of the first movie.
/home/about displays location via google maps.
/Home/apply is the user registration page.
/Home/thanks user can click view to access record list.
After clicking /home/list view the user list is displayed on this page

deficiencies
Photos added to the application cannot be viewed on the site.
The submit button in the user registration section cannot be activated.
Therefore, it is not added to the user list.